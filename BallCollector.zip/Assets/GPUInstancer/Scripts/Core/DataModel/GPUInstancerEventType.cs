﻿namespace GPUInstancer
{
    public enum GPUInstancerEventType
    {
        DetailInitializationFinished,
        TreeInitializationFinished
    }
}