﻿namespace GPUInstancer
{
    public enum GPUInstancerTreeType
    {
        None,
        MeshTree,
        TreeCreatorTree,
        SoftOcclusionTree,
        SpeedTree,
        SpeedTree8
    }
}